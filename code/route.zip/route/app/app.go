package app

import (
	_ "gin/frame/app/goods"
	_ "gin/frame/app/shop"
)
