package main

import (
	_ "github.com/gin-gonic/gin"
	_ "github.com/goinggo/mapstructure"
	_ "github.com/sirupsen/logrus"
	"test/sign"
)

func main() {
	sign.TestDemo()

	//time.Time()

	//md5.GetMD5()

	//redis.TestRedis()

	//rand.GetRoundString()

	//errgroup.ErrGroup()
	//errgroup.ErrContext()

	//mapStruct.MapStructure()

	//fmt.Println(strings.HasSuffix("this is test", "est"))

	//atomic.Atomic()
	//atomic.Value()

	//gorm.PreLoad()

	//http.Client()

	//gin.Https()

	//var pic bytes.Buffer
	//pic.WriteString(Uuid.NewV1().String())
	//pic.WriteString(".pic")
	//fmt.Println(pic.String())
	//fmt.Println(Uuid.NewV4().String())

	// 用于真正解析命令参数， 并将值赋给相应的变量
	//flag.Parse()
	//fmt.Printf("hello, %s", name) // 调用方式 go run main.go --name=will
	//logrus.SetReportCaller(true)
	//logrus.Info("info msg")

	//exec := xxl.NewExecutor(
	//	xxl.ServerAddr("http://127.0.0.1/xxl-job-admin"),
	//	xxl.ExecutorIp("127.0.0.1"),    //可自动获取
	//	xxl.ExecutorPort("9999"),        //默认9999（非必填）
	//	xxl.RegistryKey("golang-jobs"),
	//)
	//exec.Init()
	//exec.RegTask("task.test",task.Test)
	//exec.RegTask("task.test2",task.Test2)
	//exec.Run()

	//meta := &test{}
	//if meta != nil {
	//	fmt.Println(213)
	//}
}

// 结构体不为空
type Metadata struct {
	keys []string

	unued []string
}
type test struct {
}
