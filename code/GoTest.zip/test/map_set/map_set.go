package map_set

import "fmt"

// 利用map实现一个不重复的set集合
func mapSet()  {
	hashSet := make(map[string]struct{})
	data := []string{"Hello", "World", "213", "3213", "213", "World"}
	for _, datum := range data {
		hashSet[datum] = struct{}{}
	}
	for s, _ := range hashSet {
		fmt.Sprintf(s)
	}
}
