package upload

import (
	"github.com/gabriel-vasile/mimetype"
	"github.com/gin-gonic/gin"
	Uuid "github.com/satori/go.uuid"
	"net/http"
)

//gin.SetMode("release")
//route := gin.Default()
//// 注册中间件
//route.POST("/upload", upload.DealWithUpload)
//fmt.Println("start server 8080")
//route.Run(":8080")


// 127.0.0.1:8080/upload
// post form-data file 格式类型文件
func DealWithUpload(c *gin.Context) {
	//验证文件
	file, err := c.FormFile("file")

	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code":    9000,
			"message": "缺少文件",
			"data":    "",
		})
		return
	}
	//先判断文件大小
	if file.Size > 5*1024*1024 { //5m大小
		c.JSON(http.StatusOK, gin.H{
			"code":    9001,
			"message": "超出大小",
			"data":    "",
		})
		return
	}

	//判断文件类型
	rFile, _ := file.Open()

	// defer uFile.Close()
	// 即刻关闭
	rFile.Close()

	allowed := []string{"image/png", "image/jpeg", "image/jpg"}
	mime, err := mimetype.DetectReader(rFile)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code":    9002,
			"message": "读取信息错误",
			"data":    "",
		})
		return
	}

	if !mimetype.EqualsAny(mime.String(), allowed...) {
		c.JSON(http.StatusOK, gin.H{
			"code":    9003,
			"message": "上传类型不属于所属范围",
			"data":    "",
		})
		return
	}

	key := "dist/profile/picture/" + "omsPreview"
	fileName := Uuid.NewV1().String() + mime.Extension() //
	data := make(map[string]interface{})
	data["key"] = key
	data["fileName"] = fileName
	c.JSON(http.StatusOK, gin.H{
		"code":    9004,
		"message": "that is ok",
		"data": data,
	})
}
