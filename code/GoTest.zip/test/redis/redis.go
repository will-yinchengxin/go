package redis

import (
	"fmt"
	"github.com/garyburd/redigo/redis"
)

func initRedis() (redis.Conn, error){
	host := "127.0.0.1:16379"
	redisDb := 0
	rs, err := redis.Dial("tcp", host)
	//defer rs.Close()

	if err != nil {
		fmt.Println(err)
		fmt.Println("redis connect error")
		return nil, err
	}
	rs.Do("SELECT", redisDb)
	return rs, nil
}

func TestRedis() {
	//rd, _ := initRedis()
	// 操作redis时调用Do方法，第一个参数传入操作名称（字符串），然后根据不同操作传入key、value、数字等
	// 返回2个参数，第一个为操作标识，成功则为1，失败则为0；第二个为错误信息
	//rd.Do("SET", "name", "will")

	// send 结合 flush 可以批量执行多个命令
	//rd.Send("SET", "age", 18)
	//rd.Send("SET", "sex", "man")
	//rd.Flush()


	/*事务执行*/
	//rd.Send("MULTI")
	//rd.Send("INCR", "foo")
	//rd.Send("INCR", "bar")
	//r, _ := rd.Do("EXEC")
	//fmt.Println(r) // prints [1, 1]

	// Exists
	// fmt.Println(redis.Bool(rd.Do("EXISTS", "name")))

	// mget
	//reply, _ := redis.Values(rd.Do("MGET", "name", "sex"))
	//var name string
	//var sex string
	//redis.Scan(reply, &name, &sex)
	//fmt.Println(name, sex)


}