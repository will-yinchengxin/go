package reflect

import (
	"fmt"
	"reflect"
	"strings"
)

type rawVal struct {
	DecimalSeparator  string `jpath:"userContext.conversationCredentials.sessionToken"`
	GroupingSeparator string `jpath:"userContext.valid"`
	GroupPattern      string `jpath:"userContext.cobrandId"json:"group_pattern"`
}

var TestMap = map[string]interface{}{"userContext": map[string]interface{}{"userContext": map[string]interface{}{"sessionToken": "06142010_1:b8d011fefbab8bf1753391b074ffedf9578612d676ed2b7f073b5785b"}, "valid": "true", "cobrandId": "1.0000004e+07"}}

func GetStruct() {
	var rawVal rawVal
	//rawVal := rawVal{}
	mapToStruct(TestMap, &rawVal)
}

func mapToStruct(m map[string]interface{}, rawVal interface{}) (bool, error) {
	decoded := false

	var val reflect.Value
	reflectRawValue := reflect.ValueOf(rawVal)
	kind := reflectRawValue.Kind()
	//fmt.Println(reflectRawValue, kind) // &{  } ptr

	switch kind {
	case reflect.Ptr:
		// 获取值类型
		val = reflectRawValue.Elem() // fmt.Println(val) // {}
		if val.Kind() != reflect.Struct {
			return decoded, fmt.Errorf("Incompatible Type : %v : Looking For Struct", kind)
		}
	case reflect.Struct:
		var ok bool
		val, ok = rawVal.(reflect.Value)
		if ok == false {
			return decoded, fmt.Errorf("Incompatible Type : %v : Looking For reflect.Value", kind)
		}
	default:
		return decoded, fmt.Errorf("Incompatible Type : %v", kind)
	}

	// 遍历结构体字段，以 GroupPattern 为例
	for i := 0; i < val.NumField(); i++ {
		valueField := val.Field(i)
		fmt.Println(valueField)
		//---------------------------------------------------
		indexName := val.Type().Field(i).Name
		fmt.Println(indexName) // GroupPattern
		indexIndex := val.Type().Field(i).Index
		fmt.Println(indexIndex) // [2]
		typeField := val.Type().Field(i)
		fmt.Println(typeField) // {GroupPattern  string jpath:"userContext.cobrandId"json:"group_pattern" 32 [2] false}
		tag := typeField.Tag
		fmt.Println(tag) // jpath:"userContext.cobrandId"json:"group_pattern"
		tagValue := tag.Get("jpath")
		fmt.Println(tagValue) // userContext.cobrandId
		//-----------------------------------------------------

		keys := strings.Split(tagValue, ".")
		data := findData(m, keys)
		if data != nil {
			// 更改反转状态
			decoded = true
			err := Decode("", data, valueField)
			if err != nil {
				return false, err
			}
		}
	}
	return decoded, nil
}

// 多维map查找指定键值
func findData(m map[string]interface{}, keys []string) interface{} {
	if len(keys) == 1 {
		if value, ok := m[keys[0]]; ok == true {
			return value
		}
		return nil
	}

	if value, ok := m[keys[0]]; ok == true {
		if m, ok := value.(map[string]interface{}); ok == true {
			return findData(m, keys[1:])
		}
	}

	return nil
}

func Decode(name string, data interface{}, val reflect.Value) error {
	if data == nil {
		return nil
	}
	dataVal := reflect.ValueOf(data)
	// IsValid 校验的是flag
	if !dataVal.IsValid() {
		// 如果value是为经过校验的，那么返回对应类型的 0 值
		val.Set(reflect.Zero(val.Type()))
		return nil
	}

 	return nil
}