package regexp

import (
	"fmt"
	"regexp"
	"strings"
)

func Regexp() {
	var url = "https://developer-fat.shadowcreator.com/file#房贷首付"
	r, _ := regexp.Compile("#(.*)")
	b := r.MatchString(url)
	if !b {
		fmt.Println("链接未能匹配出标题内容")
	}
	fmt.Println(strings.TrimLeft(r.FindString(url), "#"))
}
