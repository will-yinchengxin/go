package time

import (
	"fmt"
	"time"
)

var Name string

func Time() {
	now := time.Now()
	// 获取当前时间
	fmt.Println(now.Format("2006-01-02 15:04:05")) // 2021-08-27 15:14:49
	// 获取指定间隔后的时间
	//now.Add(time.Hour * 2)
	deadTime := time.Date(now.Year(), now.Month(), now.Day(), now.Add(time.Hour * 1).Hour(), now.Minute(), now.Second(), 0, now.Location()).Format("2006-01-02 15:04:05")
	fmt.Println(deadTime)

	// 时间戳
	timestamp1 := now.Unix()     // 毫秒时间戳 1630048018
	timestamp2 := now.UnixNano() // 纳秒时间戳
	fmt.Println(timestamp1, timestamp2)

	// 将时间戳转为时间格式
	timer := time.Unix(1630048018, 0)
	timerNow := time.Unix(1630048018, 0).Format("2006-01-02 15:04:05") // 2021-08-27 15:06:58
	fmt.Println(timerNow)
	fmt.Println(timer.Year(), timer.Month(), timer.Day(), timer.Hour(), timer.Second(), timer.Minute())

	// 定时器
	//for i := range time.Tick(time.Second) {
	//	fmt.Println(i)
	//}


}
