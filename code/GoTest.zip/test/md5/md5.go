package md5

import (
	"crypto/md5"
	"encoding/hex"
	"fmt"
)

func GetMD5() {
	md5Ctx := md5.New()
	md5Ctx.Write([]byte("test md5 encrypto"))
	cipherStr := md5Ctx.Sum(nil)
	fmt.Print(cipherStr, "\n")
	fmt.Print(hex.EncodeToString(cipherStr))
}

func EncryptPassword() {
	h1 := md5.New()
	h1.Write([]byte("test md5 encrypto"))
	f1 := hex.EncodeToString(h1.Sum(nil))

	h2 := md5.New()
	h2.Write([]byte(f1))
	// 增加 盐值
	h2.Write([]byte("add salt"))
	f2 := hex.EncodeToString(h2.Sum(nil))
	fmt.Println(f2)
}
