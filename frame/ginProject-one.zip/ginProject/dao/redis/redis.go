package redis

import (
	"fmt"
	"github.com/spf13/viper"
	"go.uber.org/zap"

	"github.com/go-redis/redis"
)

var (
	client *redis.Client
	Nil    = redis.Nil
)

// Init 初始化连接
func Init() (err error) {
	client = redis.NewClient(&redis.Options{
		Addr:         fmt.Sprintf("%s:%d",
			viper.GetString("redis.host"),
			viper.GetInt("redis.port"),
		),
		Password:     viper.GetString("redis.password"),
		DB:           viper.GetInt("redis.dbname"),       // use default DB
		PoolSize:     viper.GetInt("redis.poolsize"),
		MinIdleConns: viper.GetInt("redis.minidleconne"),
	})

	_, err = client.Ping().Result()
	if err != nil {
		zap.L().Error("client.Ping() fail", zap.Error(err))
		return err
	}
	return nil
}

func Close() {
	_ = client.Close()
}
