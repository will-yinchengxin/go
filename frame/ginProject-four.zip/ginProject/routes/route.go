package routes

import (
	"ginProject/controller"
	"ginProject/logger"
	"github.com/gin-gonic/gin"
	"net/http"
)

func SetUp() *gin.Engine {
	// 设置为发布模式
	//gin.SetMode(gin.ReleaseMode)

	r := gin.New()
	// 使用我们zap接管的日志中间件
	r.Use(logger.GinLogger(), logger.GinRecovery(true))

	r.GET("/", func(context *gin.Context) {
		context.String(http.StatusOK, "this is the ginProject! make by Will")
	})

	r.POST("/signUp", controller.SignUp)

	r.POST("/login", controller.Login)

	return r
}
