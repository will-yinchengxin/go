package controller

import (
	"ginProject/controller/response"
	T "ginProject/controller/validator"
	"ginProject/logic"
	"ginProject/model"
	"github.com/gin-gonic/gin"
	"github.com/go-playground/validator/v10"
	"go.uber.org/zap"
	"net/http"
)

func SignUp(c *gin.Context) {
	// 参数校验
	//var p model.SignUpParams
	//p := model.SignUpParam s{}
	p := new(model.SignUpParams) // 创建指针类型
	if err := c.ShouldBindJSON(p); err != nil {
		// 记录日志
		zap.L().Debug("SignUp fail, cause param wrong", zap.Error(err))
		// 判断错误类型,如果为校验器可读类型进行翻译返回错误信息
		errs, ok := err.(validator.ValidationErrors)
		if !ok {
			// 非validator.ValidationErrors类型错误直接返回
			c.JSON(http.StatusOK, gin.H{
				"msg": err.Error(),
			})
			return
		}
		// validator.ValidationErrors类型错误则进行翻译
		c.JSON(http.StatusOK, gin.H{
			"msg": errs.Translate(T.Trans),
		})
		return
	}
	// 手动对参数进行校验
	//if len(p.Password) == 0 || len(p.UserName) == 0 || len(p.RePassword) == 0 || p.RePassword != p.Password {
	//	// 记录日志
	//	zap.L().Debug("SignUp fail, cause param wrong")
	//	c.JSON(http.StatusInternalServerError, gin.H{
	//		"msg" : "请求参数有误",
	//	})
	//	return
	//}

	// 业务处理
	if err := logic.SignUp(p); err != nil {
		//c.JSON(http.StatusOK, gin.H{
		//	"msg": "注册失败",
		//})
		response.ResponseFail(c, response.CodeSignUpFail)
		return
	}

	// 数据返回
	c.JSON(http.StatusOK, "signUp success!")
}

func Login(c *gin.Context) {
	p := new(model.LoginParams) // 创建指针类型
	if err := c.ShouldBindJSON(p); err != nil {
		// 记录日志
		zap.L().Debug("Login fail, cause param wrong", zap.Error(err))
		// 判断错误类型,如果为校验器可读类型进行翻译返回错误信息
		errs, ok := err.(validator.ValidationErrors)
		if !ok {
			// 非validator.ValidationErrors类型错误直接返回
			c.JSON(http.StatusOK, gin.H{
				"msg": err.Error(),
			})
			return
		}
		// validator.ValidationErrors类型错误则进行翻译
		c.JSON(http.StatusOK, gin.H{
			"msg": errs.Translate(T.Trans),
		})
		return
	}

	// 登录的业务处理
	if err := logic.Login(p); err != nil {
		//c.JSON(http.StatusOK, gin.H{
		//	"msg": err.Error(),
		//})
		response.ResponseFail(c, response.CodeLoginFail)
		return
	}

	// 数据返回
	//c.JSON(http.StatusOK, "Login success!")
	response.ResponseSuccess(c, nil)
}
