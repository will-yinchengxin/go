package response

type ResCode int64

const (
	CodeSuccess ResCode = 1000 + iota
	CodeFail
	CodeParamsError
	CodeWithOutLogin
	CodeUserExist
	CodeServerBusy
	CodeLoginFail
	CodeSignUpFail
)

var codeMsgMap = map[ResCode]string{
	CodeSuccess:      "success",
	CodeFail:         "fail",
	CodeLoginFail:    "login fail",
	CodeParamsError:  "param error",
	CodeWithOutLogin: "without login",
	CodeUserExist:    "user exist",
	CodeServerBusy:   "server busy try again latter",
	CodeSignUpFail:   "sign up fail",
}

func (c ResCode) Msg() string {
	msg, ok := codeMsgMap[c]
	if !ok {
		msg = codeMsgMap[CodeServerBusy]
	}
	return msg
}
