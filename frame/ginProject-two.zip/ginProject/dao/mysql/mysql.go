package mysql

import (
	"fmt"
	"ginProject/settings"
	"github.com/spf13/viper"
	"go.uber.org/zap"

	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"
)

var db *sqlx.DB

// Init 初始化MySQL连接
func Init(cfg *settings.MySQLConfig) (err error) {
	// "user:password@tcp(host:port)/dbname"
	dsn := fmt.Sprintf("%s:%d@tcp(%s:%d)/%s?parseTime=true&loc=Local",
		cfg.User,
		cfg.Password,
		cfg.Host,
		cfg.Port,
		cfg.DB,
	)
	db, err = sqlx.Connect("mysql", dsn)
	if err != nil {
		// zap.Error(err) 存储一个结构化的日志信息
		zap.L().Error("mysql sqlx.Connect fail", zap.Error(err))
		return
	}
	db.SetMaxOpenConns(viper.GetInt("mysql.maxopenconns"))
	db.SetMaxIdleConns(viper.GetInt("mysql.maxidleconns"))
	return
}

// Close 关闭MySQL连接
func Close() {
	_ = db.Close()
}
