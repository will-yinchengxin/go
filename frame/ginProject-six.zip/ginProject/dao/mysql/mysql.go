package mysql

import (
	"fmt"
	"ginProject/settings"
	"github.com/spf13/viper"
	"go.uber.org/zap"

	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"
)

var Db *sqlx.DB

// Init 初始化MySQL连接
func Init(cfg *settings.MySQLConfig) (err error) {
	// "user:password@tcp(host:port)/dbname"
	// 如果返回数据格式需要格式化时间戳,那就要把 parseTime=true 加上
	dsn := fmt.Sprintf("%s:%d@tcp(%s:%d)/%s?parseTime=true&loc=Local",
		cfg.User,
		cfg.Password,
		cfg.Host,
		cfg.Port,
		cfg.DB,
	)
	Db, err = sqlx.Connect("mysql", dsn)
	if err != nil {
		// zap.Error(err) 存储一个结构化的日志信息
		zap.L().Error("mysql sqlx.Connect fail", zap.Error(err))
		return
	}
	Db.SetMaxOpenConns(viper.GetInt("mysql.maxopenconns"))
	Db.SetMaxIdleConns(viper.GetInt("mysql.maxidleconns"))
	return
}

// Close 关闭MySQL连接
func Close() {
	_ = Db.Close()
}
