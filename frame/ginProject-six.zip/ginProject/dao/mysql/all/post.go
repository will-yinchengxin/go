package all

import (
	"ginProject/dao/mysql"
	"ginProject/model"
)

func CreatePost(p *model.Post) (err error) {
	sqlStr := `insert into post(
	post_id, title, content, author_id, community_id)
	values (?, ?, ?, ?, ?)
	`
	_, err = mysql.Db.Exec(sqlStr, p.ID, p.Title, p.Content, p.AuthorID, p.CommunityID)
	return
}

func GetPostById(Id int64) (result *model.Post, err error) {
	sqlStr := `select
	post_id, title, content, author_id, community_id, create_time
	from post
	where post_id = ?
	`
	result = new(model.Post)
	err = mysql.Db.Get(result, sqlStr, Id)
	return
}
