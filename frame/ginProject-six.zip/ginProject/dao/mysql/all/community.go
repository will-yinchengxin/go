package all

import (
	"database/sql"
	"ginProject/dao/mysql"
	"ginProject/model"
	"go.uber.org/zap"
)

func GetCommunityList() (communityList []*model.Community, err error) {
	sqlStr := "select id, community_id, community_name from community"
	if err := mysql.Db.Select(&communityList, sqlStr); err != nil {
		if err == sql.ErrNoRows {
			zap.L().Warn("there is no community in db")
			err = nil
		}
	}
	return
}

func CommunityGetById(Id int64) (result *model.CommunityDetail, err error) {
	sqlStr := "select id, community_id, community_name, introduction from community where id = ?"
	result = new(model.CommunityDetail)
	if err := mysql.Db.Get(result, sqlStr, Id); err != nil {
		err = model.ErrorInvalidId
	}
	return result, err
}
