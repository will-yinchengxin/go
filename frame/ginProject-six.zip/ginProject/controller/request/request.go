package request

import (
	"errors"
	"github.com/gin-gonic/gin"
)

const CtxUserIDKey = "user_id"
const CtxUserNameKey = "username"

var ErrorUserNotLogin = errors.New("用户未登录")

// 获取当前登录用户id
func GetCurrentUserID(c *gin.Context) (userId int64, err error) {
	uid, ok := c.Get(CtxUserIDKey)
	if !ok {
		err = ErrorUserNotLogin
		return
	}
	userId, ok = uid.(int64)
	if !ok {
		err = ErrorUserNotLogin
		return
	}
	return
}

// 获取当前登录用户name
func GetCurrentUserName(c *gin.Context) (userName string, err error) {
	username, ok := c.Get(CtxUserNameKey)
	if !ok {
		err = ErrorUserNotLogin
		return
	}
	userName, ok = username.(string)
	if !ok {
		err = ErrorUserNotLogin
		return
	}
	return
}
