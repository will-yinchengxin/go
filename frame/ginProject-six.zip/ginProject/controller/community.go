package controller

import (
	"ginProject/controller/response"
	"ginProject/logic"
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"strconv"
)

// ---------社区信息----------
func CommunityList(c *gin.Context) {
	// 查询社区列表信息
	data, err := logic.CommunityList()
	if err != nil {
		zap.L().Error("logic.community err", zap.Any("err", err))
		response.ResponseFail(c, response.CodeFail)
		return
	}
	response.ResponseWithSuccessMessage(c, "success", data)
}

func CommunityGetById(c *gin.Context) {
	idStr := c.Param("id")
	var Id, err = strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		response.ResponseFail(c, response.CodeParamsError)
		return
	}
	// 根据id 获取社区信息详情
	data, err := logic.CommunityGetById(Id)
	if err != nil {
		zap.L().Error("logic.CommunityGetById err", zap.Error(err))
		response.ResponseFail(c, response.CodeFail)
		return
	}
	response.ResponseWithSuccessMessage(c, "success", data)
}
