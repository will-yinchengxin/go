package response

type ResCode int64

const (
	CodeSuccess ResCode = 1000 + iota
	CodeFail
	CodeParamsError
	CodeWithOutLogin
	CodeUserExist
	CodeServerBusy
	CodeLoginFail
	CodeSignUpFail
	CodeNeedAuth
	CodeTokenExpire
	CodeInvalidToken
)

var codeMsgMap = map[ResCode]string{
	CodeSuccess:      "success",
	CodeFail:         "fail",
	CodeLoginFail:    "login fail",
	CodeParamsError:  "param error",
	CodeWithOutLogin: "without login",
	CodeUserExist:    "user exist",
	CodeServerBusy:   "server busy try again latter",
	CodeSignUpFail:   "sign up fail",
	CodeNeedAuth:     "need auth",
	CodeTokenExpire:  "token expire",
	CodeInvalidToken: "need token",
}

func (c ResCode) Msg() string {
	msg, ok := codeMsgMap[c]
	if !ok {
		msg = codeMsgMap[CodeServerBusy]
	}
	return msg
}
