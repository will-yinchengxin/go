package controller

import (
	"ginProject/controller/request"
	"ginProject/controller/response"
	"ginProject/logic"
	"ginProject/model"
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"strconv"
)

func CreatePost(c *gin.Context) {
	param := new(model.Post)
	if err := c.ShouldBindJSON(param); err != nil {
		zap.L().Error("CreatePost c.ShouldBindJSON err cause", zap.Error(err))
		response.ResponseFail(c, response.CodeParamsError)
		return
	}
	// 利用jwt获取当前用户id
	userId, err := request.GetCurrentUserID(c)
	if err != nil {
		response.ResponseFail(c, response.CodeWithOutLogin)
		return
	}
	param.AuthorID = int64(userId)
	if err := logic.CreatePost(param); err != nil {
		zap.L().Error("logic.CreatePost(param) cause", zap.Error(err))
		response.ResponseFail(c, response.CodeFail)
		return
	}

	response.ResponseWithSuccessMessage(c, "CreatePost success", param)
}

func GetPostById(c *gin.Context) {
	idStr := c.Param("id")
	Id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		response.ResponseFail(c, response.CodeParamsError)
	}
	data, err := logic.GetPostById(Id)
	if err != nil {
		zap.L().Error("logic.GetPostById err", zap.Error(err))
		response.ResponseFail(c, response.CodeFail)
		return
	}
	response.ResponseWithSuccessMessage(c, "success", data)
}
