package model

import "time"

type Community struct {
	Id            string `json:"Id" db:"id"`
	CommunityId   int64  `json:"CommunityId" db:"community_id"`
	CommunityName string `json:"CommunityName" db:"community_name"`
}

type CommunityDetail struct {
	Id            int64     `db:"id"`
	CommunityId   int64     `db:"community_id"`
	CommunityName string    `db:"community_name"`
	Introduction  string    `db:"introduction"`
	CreateTime    time.Time `db:"create_time"`
}
