package model

import "errors"

var (
	ErrorInvalidId = errors.New("id is invalid")
)
