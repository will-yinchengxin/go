package logic

import (
	"ginProject/dao/mysql/all"
	"ginProject/model"
)

func CommunityList() ([]*model.Community, error) {
	// 查数据库 查找到所有的community 并返回
	return all.GetCommunityList()
}

func CommunityGetById(Id int64) (*model.CommunityDetail, error) {
	// 查数据库 查找到所有的community 并返回
	return all.CommunityGetById(Id)
}
