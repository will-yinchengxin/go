package logic

import (
	"ginProject/dao/mysql/all"
	"ginProject/libraries"
	"ginProject/model"
)

func CreatePost(post *model.Post) error {
	post.ID = libraries.GenID()
	// 进行用户插入
	err := all.CreatePost(post)
	if err != nil {
		return err
	}
	return nil
}

func GetPostById(Id int64) (result *model.Post, err error) {
	return all.GetPostById(Id)
}
