> #windows下端口被占用
- netstat -ano | findstr <端口号>
- taskkill /F /pid <查询到的pid>