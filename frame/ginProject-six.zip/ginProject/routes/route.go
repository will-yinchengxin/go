package routes

import (
	"ginProject/controller"
	"ginProject/logger"
	"ginProject/middleware"
	"github.com/gin-gonic/gin"
)

func SetUp() *gin.Engine {
	// 设置为发布模式
	//gin.SetMode(gin.ReleaseMode)

	r := gin.New()
	// 使用我们zap接管的日志中间件
	r.Use(logger.GinLogger(), logger.GinRecovery(true))

	v1 := r.Group("/api/v1")

	// 登录注册接口
	v1.POST("/signUp", controller.SignUp)
	v1.POST("/login", controller.Login)

	// 使用JWT中间件
	v1.Use(middleware.JWTAuthMiddleware())
	{
		// 社区信息(列表)
		v1.GET("/community", controller.CommunityList)
		// 路径参数
		v1.GET("/community/info/:id", controller.CommunityGetById)

		// 帖子部分
		v1.POST("/post/create", controller.CreatePost)
		v1.GET("/post/info/:id", controller.GetPostById)
	}

	return r
}

//// JWTAuthMiddleware 基于JWT的认证中间件
//func JWTAuthMiddleware() func(c *gin.Context) {
//	return func(c *gin.Context) {
//		// 客户端携带Token有三种方式 1.放在请求头 2.放在请求体 3.放在URI
//		// 这里假设Token放在Header的Authorization中，并使用Bearer开头
//		// 这里的具体实现方式要依据你的实际业务情况决定
//		authHeader := c.Request.Header.Get("Authorization")
//		if authHeader == "" {
//			c.JSON(http.StatusOK, gin.H{
//				"code": 1006,
//				"msg":  "请求头中auth为空",
//			})
//			c.Abort()
//			return
//		}
//		// 按空格分割
//		parts := strings.SplitN(authHeader, " ", 2)
//		if !(len(parts) == 2 && parts[0] == "Bearer") {
//			c.JSON(http.StatusOK, gin.H{
//				"code": 1007,
//				"msg":  "请求头中auth格式有误",
//			})
//			c.Abort()
//			return
//		}
//		// parts[1]是获取到的tokenString，我们使用之前定义好的解析JWT的函数来解析它
//		mc, err := libraries.ParseToken(parts[1])
//		if err != nil {
//			c.JSON(http.StatusOK, gin.H{
//				"code": 1008,
//				"msg":  "无效的Token",
//			})
//			c.Abort()
//			return
//		}
//		// 将当前请求的user_id, username信息保存到请求的上下文c上
//		c.Set("username", mc.Username)
//		c.Set("user_id", mc.UserId)
//		c.Next() // 后续的处理函数可以用过c.Get("username")来获取当前请求的用户信息
//	}
//}
