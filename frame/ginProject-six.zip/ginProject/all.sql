/*
 Navicat Premium Data Transfer

 Source Server         : go
 Source Server Type    : MySQL
 Source Server Version : 80025
 Source Host           : localhost:13306
 Source Schema         : go_frame

 Target Server Type    : MySQL
 Target Server Version : 80025
 File Encoding         : 65001

 Date: 27/06/2021 21:23:15
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for community
-- ----------------------------
DROP TABLE IF EXISTS `community`;
CREATE TABLE `community`  (
                              `id` int(0) NOT NULL AUTO_INCREMENT,
                              `community_id` int(0) UNSIGNED NOT NULL,
                              `community_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
                              `introduction` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
                              `create_time` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
                              `update_time` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
                              PRIMARY KEY (`id`) USING BTREE,
                              UNIQUE INDEX `idx_community_id`(`community_id`) USING BTREE,
                              UNIQUE INDEX `idx_community_name`(`community_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of community
-- ----------------------------
INSERT INTO `community` VALUES (1, 1, 'Go', 'this is go project', '2021-06-26 13:49:07', '2021-06-26 13:49:07');
INSERT INTO `community` VALUES (2, 2, 'PHP', 'this is php project', '2021-06-26 13:49:29', '2021-06-26 13:49:29');
INSERT INTO `community` VALUES (3, 3, 'Java', 'this is java project', '2021-06-26 13:49:51', '2021-06-26 13:49:51');

-- ----------------------------
-- Table structure for post
-- ----------------------------
DROP TABLE IF EXISTS `post`;
CREATE TABLE `post`  (
                         `id` bigint(0) NOT NULL AUTO_INCREMENT,
                         `post_id` bigint(0) NOT NULL COMMENT '帖子id',
                         `title` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '标题',
                         `content` varchar(8192) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '内容',
                         `author_id` bigint(0) NOT NULL COMMENT '作者的用户id',
                         `community_id` bigint(0) NOT NULL COMMENT '所属社区',
                         `status` tinyint(0) NOT NULL DEFAULT 1 COMMENT '帖子状态',
                         `create_time` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
                         `update_time` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '更新时间',
                         PRIMARY KEY (`id`) USING BTREE,
                         UNIQUE INDEX `idx_post_id`(`post_id`) USING BTREE,
                         INDEX `idx_author_id`(`author_id`) USING BTREE,
                         INDEX `idx_community_id`(`community_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of post
-- ----------------------------
INSERT INTO `post` VALUES (1, 516714831810560, 'will test one', 'this is will test two', 108673984630784, 2, 1, '2021-06-27 10:13:14', '2021-06-27 10:13:14');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
                         `id` bigint(0) NOT NULL AUTO_INCREMENT,
                         `user_id` bigint(0) NOT NULL,
                         `username` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
                         `password` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
                         `email` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
                         `gender` tinyint(0) NOT NULL DEFAULT 0,
                         `create_time` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
                         `update_time` timestamp(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
                         PRIMARY KEY (`id`) USING BTREE,
                         UNIQUE INDEX `idx_username`(`username`) USING BTREE,
                         UNIQUE INDEX `idx_user_id`(`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, 108673984630784, 'willyin', '31323334353618218139eec55d83cf82679934e5cd75', NULL, 0, '2021-06-06 07:11:49', '2021-06-20 07:12:24');

SET FOREIGN_KEY_CHECKS = 1;
