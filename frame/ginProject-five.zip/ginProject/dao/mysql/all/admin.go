package all

import (
	"crypto/md5"
	"database/sql"
	"encoding/hex"
	"errors"
	"fmt"
	"ginProject/dao/mysql"
	"ginProject/model"
)

const secret = "will"

func InsertUser(user *model.User) error {
	// 最用户密码进行加密
	user.Password = encryptPassword(user.Password)
	// 执行sql插入
	sqlStr := `insert into user (username, password, user_id) values(?, ?, ?)`
	_, err := mysql.Db.Exec(sqlStr, user.Username, user.Password, user.UserId)
	return err
}

func FindByUserName(username string) error {
	// 根据用户名查找用户信息
	sqlStr := `select count(*) from user where username = ?`
	var count int
	if err := mysql.Db.Get(&count, sqlStr, username); err != nil {
		return err
	}
	if count > 0 {
		errors.New("用户已存在")
	}
	return nil
}

func CheckLogin(user *model.User) error {
	oPassword := user.Password // 用户登录的密码
	sqlStr := `select user_id, username, password from user where username = ?`
	err := mysql.Db.Get(user, sqlStr, user.Username)
	fmt.Println(err)
	if err == sql.ErrNoRows {
		return errors.New("用户不存在")
	}
	if err != nil {
		return err
	}
	if user.Password != encryptPassword(oPassword) {
		return errors.New("密码错误")
	}
	return nil
}

// encryptPassword 密码加密
func encryptPassword(oPassword string) string {
	h := md5.New()
	h.Write([]byte(secret))
	return hex.EncodeToString(h.Sum([]byte(oPassword)))
}
