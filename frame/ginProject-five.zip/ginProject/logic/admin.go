package logic

import (
	"ginProject/dao/mysql/all"
	libraries "ginProject/libraries"
	"ginProject/model"
)

func SignUp(p *model.SignUpParams) (err error) {
	err = all.FindByUserName(p.Username)
	if err != nil {
		return err
	}

	// 雪花算法生成userId
	userId := libraries.GenID()
	// 构造User 实例
	u := &model.User{
		UserId:   userId,
		Username: p.Username,
		Password: p.Password,
	}
	// 进行用户插入
	return all.InsertUser(u)
}

func Login(p *model.LoginParams) (string, error) {
	user := &model.User{
		Username: p.Username,
		Password: p.Password,
	}
	err := all.CheckLogin(user)
	if err != nil {
		return "", err
	}
	// 生成用户登录token字段
	return libraries.GenToken(user.UserId, user.Username)
}
