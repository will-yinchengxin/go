package response

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

type ResponseData struct {
	Code ResCode
	Msg  interface{}
	Data interface{}
}

func ResponseFail(c *gin.Context, code ResCode) {
	c.JSON(http.StatusOK, &ResponseData{
		Code: code,
		Msg:  ResCode.Msg(code),
		Data: nil,
	})
}

func ResponseSuccess(c *gin.Context) {
	c.JSON(http.StatusOK, &ResponseData{
		Code: CodeSuccess,
		Msg:  ResCode.Msg(CodeSuccess),
		Data: nil,
	})
}

func ResponseWithSuccessMessage(c *gin.Context, msg string, data interface{}) {
	c.JSON(http.StatusOK, &ResponseData{
		Code: CodeSuccess,
		Msg:  msg,
		Data: data,
	})
}

func ResponseWithFailMessage(c *gin.Context, msg string) {
	c.JSON(http.StatusOK, &ResponseData{
		Code: CodeFail,
		Msg:  msg,
		Data: nil,
	})
}
