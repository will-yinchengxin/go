package all

func InsertUser() {

}

func FindByUserName() {

}
