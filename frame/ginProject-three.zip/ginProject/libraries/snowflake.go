package libraries

import (
	"time"

	sf "github.com/bwmarrin/snowflake"
)

var node *sf.Node

func Init(startTime string, machineID int64) (err error) {
	var st time.Time
	st, err = time.Parse("2006-01-02", startTime)
	if err != nil {
		return
	}
	sf.Epoch = st.UnixNano() / 1000000
	node, err = sf.NewNode(machineID)
	return
}
// 通过雪花算法获取唯一id
func GenID() int64 {
	return node.Generate().Int64()
}

//
//func main() {
//	if err := Init("2021-05-31", 1); err != nil {
//		fmt.Printf("get the sonwflake number fail, err %v", err)
//	}
//	fmt.Println(GenID())
//}
