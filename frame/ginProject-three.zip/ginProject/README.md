# go语言实现基于web段框架
> ### redis环境搭建
````
docker pull willyin/redis 
docker run -it -p 16379:6379 --name redis willyin/redis
````
> ### mysql环境搭建
````
docke pull mysql
docker run -d -p 13306:3306 --name mysql -e MYSQL_ROOT_PASSWORD mysql
````