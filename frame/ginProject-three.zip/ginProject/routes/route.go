package routes

import (
	"net/http"
	"ginProject/logger"
	"github.com/gin-gonic/gin"
	"ginProject/controller"
)

func SetUp() *gin.Engine {
	r := gin.New()
	// 使用我们zap接管的日志中间件
	r.Use(logger.GinLogger(), logger.GinRecovery(true))

	r.GET("/", func(context *gin.Context) {
		context.String(http.StatusOK, "this is the ginProject! make by Will")
	})

	r.POST("/signUp", controller.SignUp)

	return r
}
