package logic

import "ginProject/model"

func SignUp(p *model.SignUpParams) {

}
